@extends('layout')
@section('content')
  <h1>About Us</h1>
  <p>Learning Laravel is a beginner to intermediate level book, designed for any PHP developer at all levels. The main goal of this book is to build a solid foundation for developers to build their next web applications with Laravel.</p>
@stop