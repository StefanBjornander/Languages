<!-- block customerAdded -->
  <h1>Customer Added</h1>

  <p>Customer {{$customerName}} with number {{$customerNumber}} has been added.</p>

  <form method="get" action="/">
    <input type="submit" value="Ok">
  </form>
<!-- endblock -->