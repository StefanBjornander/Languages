<!-- block depositDone -->
  <h1>Deposit</h1>

  <p>Account number {{$accountNumber}}, owned by {{$customerName}} with
     number {{$customerNumber}}, has been deposited with {{$amount}} kr.</p>

  <form method="get" action="/">
    <input type="submit" value="Ok">
  </form>
<!-- endblock -->