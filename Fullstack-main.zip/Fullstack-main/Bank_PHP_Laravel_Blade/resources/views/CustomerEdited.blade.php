<!-- block customerEdited -->
  <h1>Customer Edited</h1>

  <p>The name of the customer with number {{$customerNumber}}
     has been changed from {{$customerOldName}} to {{$customerNewName}}.</p>

  <form method="get" action="/">
    <input type="submit" value="Ok">
  </form>
<!-- endblock -->