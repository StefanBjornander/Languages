<!-- block withdrawDone -->
  <h1>Withdraw</h1>

  <p>Account number {{$accountNumber}}, owned by {{$customerName}} with
     number {{$customerNumber}}, has been withdrawn with {{$amount}} kr.</p>

  <form method="get" action="/">
    <input type="submit" value="Ok">
  </form>
<!-- endblock -->