<?php

namespace Bank\Exceptions;

use Exception;

class DbException extends Exception {
}