<?php

namespace Bank\Exceptions;

use Exception;

class NotFoundException extends Exception {
}