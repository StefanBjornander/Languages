export interface CustomerInterface {
  customer_number: number;
  customer_name: string;
}
