import { History } from './history';

describe('History', () => {
  it('should create an instance', () => {
    expect(new History()).toBeTruthy();
  });
});
