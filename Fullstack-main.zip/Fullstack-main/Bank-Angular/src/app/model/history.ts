export class History {
  constructor(public account_number: number,
              public time: Date,
              public amount: number) {
    // Empty.
  }
}