<style>
  .column {
    width: 20mm;
    align: center;
  }

  .button {
    width: 100%;
  }
</style>

<h1>Orders</h1>

<table border="1">
  Your orders have been cleared.
  <p>
  <form method="get" action="\">
    <tr align="left">
       <td colspan="5"><input class="button" type="submit" value="Main Menu"></td>
    </tr>
  </form>
</table>